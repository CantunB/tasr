/*
Template Name: Skote - Admin & Dashboard Template
Author: Themesbrand
Website: https://themesbrand.com/
Contact: themesbrand@gmail.com
File: Jquery knob init Js File
*/

$(function() {
    $(".knob").knob();
});